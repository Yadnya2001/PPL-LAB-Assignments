int Z;

void main()
{
        int a, b, c;
        int p = 6;
        int q;
//        double r;

        a = 10;
        b = 20;
       
       	c = a * b + 25;
       
       	p = 6;
        q = Z;
      /*  r = 34.5;
        Z = r;
        Z = Z + 1;
	*/
	
}

